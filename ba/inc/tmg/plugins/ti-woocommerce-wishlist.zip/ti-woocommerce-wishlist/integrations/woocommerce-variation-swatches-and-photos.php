<?php
/**
 * TI WooCommerce Wishlist integration with:
 *
 * @name WooCommerce Variation Swatches and Photos
 *
 * @version 3.0.12
 *
 * @slug woocommerce-variation-swatches-and-photos
 *
 * @url https://woocommerce.com/products/variation-swatches-and-photos/
 *
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	die;
}
